module HelloJava {
}